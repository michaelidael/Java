import java.util.ArrayList;

//Database class for project

public class Database {

//var dec

private ArrayList<Product> list;

private Product prod;

private boolean found;

private int index;


//defaultforerrorredux

public Database() {

list = new ArrayList<Product>();

prod = null;

index = 0;

found = false;

}


//searchyfx

public void search(String key) {

found = false;

int i = 0;


while (!found && i<list.size()) {

Product ez =list.get(i);

if(ez.getProductName().equalsIgnoreCase(key)) {

prod = ez;
found = true;
index = i;

}

else

i++;

}

}


//prodAdder

public void add(Product newProduct) {

list.add(newProduct);

}


//prodDeleter

public Product delete(int i) {

return list.remove(i);

}


//curridxGetter

public int getIndex() {

return index;

}


//get bool if item found || !found

public boolean inList() {

return found;

}


//product getter

public Product getProduct() {

return prod;

}


// invSize

public int size() {

return list.size();

}


//isListEmpty?

public boolean isListEmpty() {

return list.isEmpty();

}


//invListGetter

public ArrayList<Product> getList(){

return list;

}

//concludes ungodly Datb class *whew*

}