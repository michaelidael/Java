//util use

import java.text.*;

import javax.swing.*;

import java.util.*;


//TestProd Class

public class TestProd {


//date set/get

static SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");

//MainnnnB

public static void main(String args []) throws ParseException

{

//var dec

String street,city,state,zip;

String companyName;

String productName;

String dateManu;

Database deletedProdDatb = new Database();

Date present = new Date();

int quantity;

boolean isDone = false;

double unitPrice;

Product product = new Product();

Database productDatb = new Database();

int subMenu = 0;

Manufacturer manufacture = new Manufacturer();

Address address = null;


while (!isDone)

{

int selectedMenu = GetData.getInt("Welcome to the Product Inventory\n\t1. Create Product\n" + "\t2. Update Product (Quantity/Price)\n\t3. Delete Product\n" + "\t4. Locate a single Product\n\t5. Inventory Report\n" + "\t6. List Deleted Product(s)\n\t7. Quit");

switch(selectedMenu)

{

//case to add prod.

case 1:

productName = GetData.getString("Enter the products name:");

quantity = GetData.getInt("Enter the quantity of the product:");

unitPrice = GetData.getDouble("Enter the unit price of the product($xx.xx format): ");

companyName = GetData.getString("Enter the name of the manufacturer: ");

street = GetData.getString("Enter the company's street: ");

city = GetData.getString("Enter the company's city: ");

state = GetData.getString("Enter the company's state: ");

zip = GetData.getString("Enter the company's Zip Code: ");

dateManu = GetData.getString("Enter the product's purchase date (mm/dd/yyyy format): ");

address = new Address(street,city,state,zip);

manufacture = new Manufacturer(companyName, address);

present = sdf.parse(dateManu);

product = new Product(productName, quantity, unitPrice, present, manufacture);

productDatb.add(product);



break;

//update prod price/quantity

case 2:

productName = GetData.getString("Enter product name to update: ");

subMenu = GetData.getInt("Select option to update: \n1. To update quantity\n2. To update price.\n");

productDatb.search(productName);

if(!productDatb.inList())

{

JOptionPane.showMessageDialog(null, "Error: Product not found.");

}

else {

switch (subMenu)

{

//update quant. or deduct

case 1:

int menuOpt = GetData.getInt("Select option to update: \n1 To add quantity\n2. To deduct quantity\n");

int addOrDeductQuantity = 0;

if (menuOpt < 1 || menuOpt > 2)

{

JOptionPane.showMessageDialog(null, "Please choose the correct choice");

}

else

{


switch (menuOpt)

{


case 1:

addOrDeductQuantity = GetData.getInt("Enter the quantity to add: ");

product = productDatb.getProduct();

product.updateQuantity(addOrDeductQuantity);

break;

// case to deduct quant

case 2:

addOrDeductQuantity = GetData.getInt("Enter the quantity to deduct: ");

product = productDatb.getProduct();

product.updateQuantity(addOrDeductQuantity * -1);

break;

}

JOptionPane.showMessageDialog(null,

"Quantity of the product is updated successfully.");

}

break;

// priceUpdate

case 2:

double priceToUpdate = GetData.getDouble("Enter the price of product to update: ");

if (priceToUpdate < 0)

{

JOptionPane.showMessageDialog(null, "Price of the product has not been updated.");

}

else

{

product = productDatb.getProduct();

product.updatePrice(priceToUpdate);

JOptionPane.showMessageDialog(null, "Price of the product has been updated successfully.");

}

break;

default:

JOptionPane.showMessageDialog(null, "Error: Unable to process option selected from update list.");

}

}

break;


//deleteprod

case 3:

productName = GetData.getString("Enter product name to update: ");

productDatb.search(productName);

if (productDatb.inList())

{

int index = productDatb.getIndex();

deletedProdDatb.add(productDatb.getProduct());

productDatb.delete(index);

JOptionPane.showMessageDialog(null,"The \"" + productName + "\" product has been deleted successfully.");

}

//else display info status of deletion.

else

{

JOptionPane.showMessageDialog(null, "Error: Product not found.");

}

break;


case 4:

productName = GetData.getString("Enter the name of the product to display: ");

productDatb.search(productName);

if (productDatb.inList())

{

displaySingleProduct(productDatb.getProduct(), JOptionPane.INFORMATION_MESSAGE);

}

else

{

JOptionPane.showMessageDialog(null, "Error: Product not found.");

}

break;

case 5:

if (productDatb.getList() != null)

{

displayInventory(productDatb, JOptionPane.INFORMATION_MESSAGE);

}

else

{

JOptionPane.showMessageDialog(null, "No products present in the inventory.");

}

break;

case 6:

if (deletedProdDatb.getList() != null)

{

displayInventory(deletedProdDatb, JOptionPane.INFORMATION_MESSAGE);

}

else

{

JOptionPane.showMessageDialog(null, "No products present in the inventory.");

}

break;


case 7:

isDone = true;

break;


//loopout safetynet

default:

JOptionPane.showMessageDialog(null, "Unable to process. Please Try Again.");

}

}

}

// get prod info formatted

public static String FormattedProdInfoGetter(Product info)

{

String result = String.format("%35s", info.getProductName());

result += String.format("%35s", sdf.format(info.getProductCreated()));

result += String.format("35s", info.getManufacture().getCompanyName());

return result;

}

//deleted list Displayer

public static void displayDeletedInventory(Database productDatb, int Type_Message)

{

String inventoryResult = "";

ArrayList<Product> prodList = productDatb.getList();

inventoryResult += String.format("%30s %30s %30s", "Product", "Purchase Date", "Manufacturer");

for (int i = 0; i < productDatb.size(); i++)

{

inventoryResult += FormattedProdInfoGetter(prodList.get(i)) + "\n";

}

JTextArea text = new JTextArea(inventoryResult, 10, 50);

JScrollPane pane = new JScrollPane(text);

JOptionPane.showMessageDialog(null, pane, "Deleted Inventory Details", Type_Message);

}

//inv display

public static void displayInventory(Database productDatb, int Type_Message)

{

String inventoryResult = "";

ArrayList<Product> prodList = productDatb.getList();

inventoryResult += String.format("%-30s \t%s %10s %15s %20s %15s\n", "Product", "Purchase Date", "Quantity",

"Price($)", "Manufacturer", "State");

for (int i = 0; i < productDatb.size(); i++)

{

inventoryResult += prodList.get(i).getProductInformation() + "\n";

}

JTextArea text = new JTextArea(inventoryResult, 10, 60);

JScrollPane pane = new JScrollPane(text);

JOptionPane.showMessageDialog(null, pane, "Inventory Details", Type_Message);

}

//single prod displayer

public static void displaySingleProduct(Product product, int Type_Message)

{

String productInfo = "Product Name: " + product.getProductName() + "\n";

productInfo += String.format("Product's Unit Price: $%.2f", product.getUnitPrice()) + "\n";

productInfo += "Quantity of product: " + product.getQuantity() + "\n";

JTextArea text = new JTextArea(productInfo, 10, 30);

JScrollPane pane = new JScrollPane(text);

JOptionPane.showMessageDialog(null, pane, product.getProductName() + " Details", Type_Message);

}

//concludes test+displayfx.

}


