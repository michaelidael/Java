//Address class for project

public class Address {


//var dec

private String street,city,state,zip;


public Address (String stre, String city, String st8, String zip) {

street = stre;

this.city = city;

state = st8;

this.zip = zip;

}


//StreetGetter

public String getStreet() {

return street;

}


//CityGetter

public String getCity() {

return city;

}


//StateGetter

public String getState() {

return state;

}


//ZipGetter

public String getZip() {

return zip;

}
}


//concludes Address class/fx