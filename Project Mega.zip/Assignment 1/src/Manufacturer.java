//manufacturer class for project

public class Manufacturer {

//var dec

private String companyName;

private Address companyAddress;


public Manufacturer() {

this.companyName = "";

this.companyAddress = null;

}


//wrapper

public Manufacturer(String compName, Address address) {

this.companyName = compName;

this.companyAddress = address;

}


//compNameGetter

public String getCompanyName() {

return companyName;

}


//compNameSetter

public void setCompanyName (String companyName) {

this.companyName = companyName;

}


//compAddressGetter

public Address getCompanyAddress() {

return companyAddress;

}


//compAddressSetter

public void setCompanyAddress(Address address) {

this.companyAddress = address;

}
}
//concludes Manufacturer Class.