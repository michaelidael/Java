/*
 * This assignment was made by Michael Soto 
 * 
 */

import java.util.Stack;

public class Preprocessor {
public static boolean isBalanced(String input) {
	
Stack<Character> stacky = new Stack<>();

  for (int i = 0; i < input.length(); i++) {
  char c = input.charAt(i);

if (c == '[' || c == '{' || c == '(' || c == '/') {

switch (c) {
case '[':
stacky.push(c);
break;

  case '{':
  stacky.push(c);
  break;

    case '(':
    stacky.push(c);
    break;

      case '/':
      char j = input.charAt(i + 1);


if (j == '*') {
stacky.push(c);
stacky.push(j);
}
break;

default:
break;
}
  
}

else if (c == ']' || c == '}' || c == ')' || c == '*') {
  
  if (stacky.empty())
  return false;

switch (c) {
case ']':
if (stacky.pop() != '[')
return false;
break;

  case '}':
  if (stacky.pop() != '{')
  return false;
  break;

    case ')':
    if (stacky.pop() != '(')
    return false;
    break;

      case '*':
      char t = input.charAt(i + 1);

if (t == '/') {
  
  if (stacky.pop() != '*')
  return false;

    if (stacky.pop() != '/')
    return false;
}

break;

default:
break;
}
}
}

  if (stacky.empty())
  return true;

return false;
}
}