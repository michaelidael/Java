import java.io.BufferedReader;
import java.io.IOException;
import java.io.FileReader;
import java.io.FileNotFoundException;

public class MyPreprocessor {
public static void main(String[]args) throws FileNotFoundException,IOException{
	//File and BufferReader
	FileReader FileReader = new FileReader("src/input.txt");
	BufferedReader BuffReader = new BufferedReader(FileReader);
	String preLine;


	if((preLine=BuffReader.readLine())!=null)

	{

	//Displays string and preprocessor check all in one 

	System.out.println("Preprocessing succesful! \n" + "Line is: "+preLine +"\nis Balanced : "+Preprocessor.isBalanced(preLine));

	}
	
	else {
		System.out.println("Preprocessing Unsuccessful! Try again \n" );
	}

	BuffReader.close();
	}


}