
	public interface Constants 
	{
		public final int WRAP_AROUND = 26;
		public final int ENCODE_SHIFT = 3;
		public final int DECODE_SHIFT = 23;	
	}
